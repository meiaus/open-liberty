define(
({
	invalidMessage: "È necessario selezionare almeno un elemento.",
	multiSelectLabelText: "{num} elementi selezionati"
})
);
