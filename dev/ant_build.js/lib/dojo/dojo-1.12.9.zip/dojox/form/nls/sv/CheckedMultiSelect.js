define(
({
	invalidMessage: "Du måste välja minst ett objekt.",
	multiSelectLabelText: "{num} objekt har valts"
})
);
