define(
({
	label: "Wybierz pliki..."
})
);
