define(
({
	invalidMessage: "Ao menos um item deve ser selecionado.",
	multiSelectLabelText: "{num} item(ns) selecionado(s)"
})
);
