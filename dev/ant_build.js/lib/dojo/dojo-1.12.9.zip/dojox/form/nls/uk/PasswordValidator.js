define(
({
	nomatchMessage: "Паролі не співпадають.",
	badPasswordMessage: "Неправильний пароль."
})
);
