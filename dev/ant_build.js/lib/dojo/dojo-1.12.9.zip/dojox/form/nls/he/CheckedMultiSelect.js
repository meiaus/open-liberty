define(
({
	invalidMessage: "יש לבחור לפחות פריט אחד.  ",
	multiSelectLabelText: "{num} פריטים נבחרו "
})
);
