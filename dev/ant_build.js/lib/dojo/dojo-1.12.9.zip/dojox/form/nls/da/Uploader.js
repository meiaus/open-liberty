define(
({
	label: "Vælg filer..."
})
);
