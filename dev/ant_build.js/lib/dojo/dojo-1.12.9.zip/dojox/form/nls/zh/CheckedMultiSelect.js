define(
({
	invalidMessage: "必须至少选择一项。",
	multiSelectLabelText: "选择了 {num} 个项"
})
);
