define(
({
	label: "ファイルの選択..."
})
);
