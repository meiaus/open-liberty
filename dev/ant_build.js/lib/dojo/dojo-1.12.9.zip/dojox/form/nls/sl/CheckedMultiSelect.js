define(
({
	invalidMessage: "Izbrati morate vsaj eno postavko.",
	multiSelectLabelText: "Število izbranih postavk: {num}"
})
);
