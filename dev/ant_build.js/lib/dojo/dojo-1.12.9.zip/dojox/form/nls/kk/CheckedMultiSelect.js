define(
({
	invalidMessage: "Кемінде бір элемент таңдалуы керек.",
	multiSelectLabelText: "{num} элемент(тер)і таңдалды"
})
);
