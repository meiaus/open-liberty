define({      
//begin v1.x content
	invalidMessage: "Mora biti izabrana makar jedna stavka.",
	multiSelectLabelText: "{num} stavki izabrano"
//end v1.x content
});

