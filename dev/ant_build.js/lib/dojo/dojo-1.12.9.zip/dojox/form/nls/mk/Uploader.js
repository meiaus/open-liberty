define({      
//begin v1.x content
	label: "Изберете датотеки..."
//end v1.x content
});

