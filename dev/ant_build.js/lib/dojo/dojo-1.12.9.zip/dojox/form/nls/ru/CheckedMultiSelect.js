define(
({
	invalidMessage: "Выберите хотя бы один элемент.",
	multiSelectLabelText: "Выбрано: {num}"
})
);
