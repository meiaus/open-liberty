define(
({
	label: "Vybrať súbory..."
})
);
