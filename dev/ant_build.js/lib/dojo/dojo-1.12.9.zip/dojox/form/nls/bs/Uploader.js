define({      
//begin v1.x content
	label: "Izbor datoteka..."
//end v1.x content
});

