define(
({
        nomatchMessage: "Құпия сөздер сәйкес емес.",
	badPasswordMessage: "Құпия сөз дұрыс емес."
})
);
