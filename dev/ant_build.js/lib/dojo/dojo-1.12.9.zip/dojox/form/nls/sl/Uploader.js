define(
({
	label: "Izberi datoteke ..."
})
);
