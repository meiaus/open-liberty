define(
({
	invalidMessage: "Du skal vælge mindst ét element.",
	multiSelectLabelText: "{num} element(er) valgt"
})
);
