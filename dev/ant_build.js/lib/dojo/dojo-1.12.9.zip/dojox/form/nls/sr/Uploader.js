define({      
//begin v1.x content
	label: "Izaberi datoteke..."
//end v1.x content
});

