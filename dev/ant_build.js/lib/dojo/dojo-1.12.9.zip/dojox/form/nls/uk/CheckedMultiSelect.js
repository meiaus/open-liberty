define(
({
	invalidMessage: "Виберіть принаймні один елемент.",
	multiSelectLabelText: "вибрано {num} елементів"
})
);
