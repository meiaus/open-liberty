define(
({
        nomatchMessage: "パスワードが一致しません。",
	badPasswordMessage: "無効なパスワードです。"
})
);
