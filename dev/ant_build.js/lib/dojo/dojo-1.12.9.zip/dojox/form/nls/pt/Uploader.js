define(
({
	label: "Selecione Arquivos..."
})
);
