define(
({
	invalidMessage: "Je třeba vybrat alespoň jednu položku.",
	multiSelectLabelText: "Počet vybraných položek: {num}"
})
);
