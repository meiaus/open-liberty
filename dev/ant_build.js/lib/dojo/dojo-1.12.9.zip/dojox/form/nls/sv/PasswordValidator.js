define(
({
        nomatchMessage: "Lösenorden överensstämmer inte.",
	badPasswordMessage: "Ogiltigt lösenord."
})
);
