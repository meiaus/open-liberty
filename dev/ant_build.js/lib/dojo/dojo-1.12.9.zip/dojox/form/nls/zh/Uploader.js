define(
({
	label: "选择文件..."
})
);
