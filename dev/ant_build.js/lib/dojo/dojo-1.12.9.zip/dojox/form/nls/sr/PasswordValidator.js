define({      
//begin v1.x content
        nomatchMessage: "Lozinke se ne podudaraju.",
	badPasswordMessage: "Nevažeća lozinka."
//end v1.x content
});

