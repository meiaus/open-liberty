define(
({
	label: "בחירת קבצים...‏"
})
);
