define(
({
	label: "Selecciona fitxers..."
})
);
