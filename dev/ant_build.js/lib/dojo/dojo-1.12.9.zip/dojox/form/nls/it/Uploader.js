define(
({
	label: "Seleziona file..."
})
);
