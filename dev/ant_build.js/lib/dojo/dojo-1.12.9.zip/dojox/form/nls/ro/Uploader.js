define(
({
	label: "Selectare fişiere..."
})
);
