define(
({
	invalidMessage: "Cal seleccionar, com a mínim, un element.",
	multiSelectLabelText: "{num} element(s) seleccionat(s)"
})
);
