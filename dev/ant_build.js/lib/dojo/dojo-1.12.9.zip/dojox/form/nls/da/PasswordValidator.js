define(
({
        nomatchMessage: "Kodeordene stemmer ikke overens.",
	badPasswordMessage: "Ugyldigt kodeord."
})
);
