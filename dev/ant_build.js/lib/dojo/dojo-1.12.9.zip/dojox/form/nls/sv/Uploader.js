define(
({
	label: "Välj filer..."
})
);
