define(
({
	label: "Vybrat soubory..."
})
);
