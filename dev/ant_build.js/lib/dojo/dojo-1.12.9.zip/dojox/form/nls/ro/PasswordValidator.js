define(
({
        nomatchMessage: "Parolele nu se potrivesc.",
	badPasswordMessage: "Parolă invalidă."
})
);
