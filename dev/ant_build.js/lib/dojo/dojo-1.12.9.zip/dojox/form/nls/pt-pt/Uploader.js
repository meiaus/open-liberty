define(
({
	label: "Seleccionar ficheiros..."
})
);
