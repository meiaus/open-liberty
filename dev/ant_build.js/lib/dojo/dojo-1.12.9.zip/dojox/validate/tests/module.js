define([
	"./creditcard",
	"./validate",
	"./br"
],1);
